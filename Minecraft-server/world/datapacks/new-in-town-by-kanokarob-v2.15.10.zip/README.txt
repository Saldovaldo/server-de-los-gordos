New in Town is brought to you by kanokarob
Huge thanks to DanMizu for simplifying the way daily resources are handled, and helping to make them more intuitive.
A special thank you to HokaLate for some much-needed optimization advice.
Thanks to TheWii for helping sort out independent town identification.
Massive thanks to the Inspired Sphere members: Ender, Eljiannelle, WyzzeWon, and Luciver89, for offering their resources to test multiplayer functionality, and for their acting in the Multiplayer trailer!
Also a thank you to Penance of Avarice for being the most-useful beta tester and suggesting several structures!

Installation Instructions
=========================
1. Create a new world, open the Data Packs folder via the Create World screen, and paste this .zip file in that folder. Cheats *do not need* to be turned on.
2. Pick up a log to add the Town Charter to your inventory. Click the words in that book at the location you want to start your settlement! You may receive a prompt if you are too close to another settlement.

Update Instructions
=========================
While in your world or server that has previously run an older version of New in Town, have an OP use the following command:
"
/function nitk:debug/update_all
"
This will update the Town Planner, War Strategist, and City Planner with the new recipe books. Players will have to re-trade for them. (Come on, it's one feather.)

Be sure to read the entirety of the latest update log, as some updates may not be compatible with older versions of New in Town.

Uninstall instructions
=========================
Before removing New in Town from your world, use "/function nitk:uninstall" to clean up excess entities. The villagers in towns, fortresses, and end cities, as well as the structures themselves, will remain, but all other features of New in Town will not work. The villagers will remain persistent, but players will become able to kill them if they choose.